ofxCameraAnaglyph
=================

Anaglyph Camera for Stereo 3D Rendering for OpenFrameworks

Based on techniques described by Paul Bourke 
http://paulbourke.net/stereographics/stereorender/

Adds anaglyph 3D rendering to OpenFrameworks for stereo 3D viewing with red/cyan 3D glasses.
![ofxCameraAnaglyph](https://farm4.staticflickr.com/3861/14863752107_3c2aebc1a4_z.jpg)
